﻿using System;
using SMS.menu;
// Connections
namespace SMS 
{
    class Program
    {
        static void Main(string[] args)
        {
                MainMenu mainMenu = new MainMenu();
                mainMenu.AllMainMenu();


            // string a = "w";
            // string b = "a";
            // string c = a+b;
            // System.Console.WriteLine(a+b);

            // DateTime dv = DateTime.Parse("2022/11/29");
            // DateTime che = DateTime.UtcNow;
            // System.Console.WriteLine(DateTime.Now.Day);
            // System.Console.WriteLine(che);
            // // System.Console.WriteLine(che-dv.Day);
            // System.Console.WriteLine((dv-che).Days+1);
            // double cashTender1;
            // while (!double.TryParse(Console.ReadLine(), out cashTender1))
            // {
            //     System.Console.WriteLine("wrong input.. Try again.");
            // }
            // string x = "1212";
            // bool dd;
            // string wrd = x.ToString();
            // for (int i = wrd.Length-1; i >= 0; i--)
            // {

            // System.Console.Write(x.ToCharArray().Reverse());


        }
    }
}

