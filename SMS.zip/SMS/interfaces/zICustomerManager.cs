/*
using SMS.model;

namespace SMS.interfaces
{
    public interface ICustomerManager
    {
        public void CreateCustomer(string firstName, string lastName, string email, string phoneNumber, int pin, string address,double wallet);
        public Customer GetCustomer(string customerId);
        public void UpdateCustomer(string customerId, string firstName, string lastName, string phoneNumber);
        public void DeleteCustomer(string customerId);
        public Customer Login (string email,  int pin);
    }
}

*/